﻿//using code from https://educ8s.tv/c-application-arduino-communication/ as reference for Serial Port Communication

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace GUI_Attempt_1
{
    public partial class Form1 : Form
    {

        bool on1 = true;
        bool on2 = true;
        bool on3 = true;
        bool on4 = true;
        bool on5 = true;
        bool on6 = true;
        bool on7 = true;
        bool on8 = true;
        bool on9 = true;
        bool on10 = true;
        bool on11 = true;
        bool on12 = true;
        bool on13 = true;
        bool on14 = true;
        bool on15 = true;
        bool on16 = true;
        bool on17 = true;
        bool on18 = true;
        bool on19 = true;
        bool on20 = true;
        bool on21 = true;
        bool on22 = true;
        bool on23 = true;
        bool on24 = true;
        bool on25 = true;


        bool Connection = false;
        string[] ports;
        SerialPort port;

        int S;
        int M;



        public Form1()
        {
            InitializeComponent();
            getAvailableComPorts();

            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
                Console.WriteLine(port);
                if (ports[0] != null)
                {
                    comboBox1.SelectedItem = ports[0];
                }
            }

        }

        void getAvailableComPorts()
        {
            ports = SerialPort.GetPortNames();
        }

        private void connectToArduino()
        {
            Connection = true;
            string selectedPort = comboBox1.GetItemText(comboBox1.SelectedItem);
            port = new SerialPort(selectedPort, 9600, Parity.None, 8, StopBits.One);
            port.Open();
            port.Write("#DAWN\n");
            button27.Text = "Disconnect";
            button27.BackColor = Color.DarkRed;

        }

        private void disconnectFromArduino()
        {
            Connection = false;
            port.Write("#STOP\n");
            port.Close();
            button27.Text = "Connect";
            button27.BackColor = Color.Green;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            {
                button1.Text = "OFF";
                button1.BackColor = Color.Gray;
                button2.Text = "OFF";
                button2.BackColor = Color.Gray;
                button3.Text = "OFF";
                button3.BackColor = Color.Gray;
                button4.Text = "OFF";
                button4.BackColor = Color.Gray;
                button5.Text = "OFF";
                button5.BackColor = Color.Gray;
                button6.Text = "OFF";
                button6.BackColor = Color.Gray;
                button7.Text = "OFF";
                button7.BackColor = Color.Gray;
                button8.Text = "OFF";
                button8.BackColor = Color.Gray;
                button9.Text = "OFF";
                button9.BackColor = Color.Gray;
                button10.Text = "OFF";
                button10.BackColor = Color.Gray;
                button11.Text = "OFF";
                button11.BackColor = Color.Gray;
                button12.Text = "OFF";
                button12.BackColor = Color.Gray;
                button13.Text = "OFF";
                button13.BackColor = Color.Gray;
                button14.Text = "OFF";
                button14.BackColor = Color.Gray;
                button15.Text = "OFF";
                button15.BackColor = Color.Gray;
                button16.Text = "OFF";
                button16.BackColor = Color.Gray;
                button17.Text = "OFF";
                button17.BackColor = Color.Gray;
                button18.Text = "OFF";
                button18.BackColor = Color.Gray;
                button19.Text = "OFF";
                button19.BackColor = Color.Gray;
                button20.Text = "OFF";
                button20.BackColor = Color.Gray;
                button21.Text = "OFF";
                button21.BackColor = Color.Gray;
                button22.Text = "OFF";
                button22.BackColor = Color.Gray;
                button23.Text = "OFF";
                button23.BackColor = Color.Gray;
                button24.Text = "OFF";
                button24.BackColor = Color.Gray;
                button25.Text = "ALL ON/OFF";
                button25.BackColor = Color.Gray;
                button27.Text = "Connect";
                button27.BackColor = Color.Green;
            }








        }


        private void button1_Click_2(object sender, EventArgs e)
        {
            if (on1)
            {
                button1.Text = "ON";
                button1.BackColor = Color.Red;
                on1 = false;

            }
            else
            {
                button1.Text = "OFF";
                button1.BackColor = Color.Gray;
                on1 = true;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (on2)
            {
                button2.Text = "ON";
                button2.BackColor = Color.Red;
                on2 = false;

            }
            else
            {
                button2.Text = "OFF";
                button2.BackColor = Color.Gray;
                on2 = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (on3)
            {
                button3.Text = "ON";
                button3.BackColor = Color.Red;
                on3 = false;

            }
            else
            {
                button3.Text = "OFF";
                button3.BackColor = Color.Gray;
                on3 = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (on4)
            {
                button4.Text = "ON";
                button4.BackColor = Color.Red;
                on4 = false;

            }
            else
            {
                button4.Text = "OFF";
                button4.BackColor = Color.Gray;
                on4 = true;
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (on5)
            {
                button5.Text = "ON";
                button5.BackColor = Color.Red;
                on5 = false;

            }
            else
            {
                button5.Text = "OFF";
                button5.BackColor = Color.Gray;
                on5 = true;
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (on6)
            {
                button6.Text = "ON";
                button6.BackColor = Color.Red;
                on6 = false;

            }
            else
            {
                button6.Text = "OFF";
                button6.BackColor = Color.Gray;
                on6 = true;
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            if (on7)
            {
                button7.Text = "ON";
                button7.BackColor = Color.Red;
                on7 = false;

            }
            else
            {
                button7.Text = "OFF";
                button7.BackColor = Color.Gray;
                on7 = true;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (on8)
            {
                button8.Text = "ON";
                button8.BackColor = Color.Red;
                on8 = false;

            }
            else
            {
                button8.Text = "OFF";
                button8.BackColor = Color.Gray;
                on8 = true;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (on9)
            {
                button9.Text = "ON";
                button9.BackColor = Color.Red;
                on9 = false;

            }
            else
            {
                button9.Text = "OFF";
                button9.BackColor = Color.Gray;
                on9 = true;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (on10)
            {
                button10.Text = "ON";
                button10.BackColor = Color.Red;
                on10 = false;

            }
            else
            {
                button10.Text = "OFF";
                button10.BackColor = Color.Gray;
                on10 = true;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (on11)
            {
                button11.Text = "ON";
                button11.BackColor = Color.Red;
                on11 = false;

            }
            else
            {
                button11.Text = "OFF";
                button11.BackColor = Color.Gray;
                on11 = true;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (on12)
            {
                button12.Text = "ON";
                button12.BackColor = Color.Red;
                on12 = false;

            }
            else
            {
                button12.Text = "OFF";
                button12.BackColor = Color.Gray;
                on12 = true;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (on13)
            {
                button13.Text = "ON";
                button13.BackColor = Color.Red;
                on13 = false;

            }
            else
            {
                button13.Text = "OFF";
                button13.BackColor = Color.Gray;
                on13 = true;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (on14)
            {
                button14.Text = "ON";
                button14.BackColor = Color.Red;
                on14 = false;

            }
            else
            {
                button14.Text = "OFF";
                button14.BackColor = Color.Gray;
                on14 = true;
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (on15)
            {
                button15.Text = "ON";
                button15.BackColor = Color.Red;
                on15 = false;

            }
            else
            {
                button15.Text = "OFF";
                button15.BackColor = Color.Gray;
                on15 = true;
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (on16)
            {
                button16.Text = "ON";
                button16.BackColor = Color.Red;
                on16 = false;

            }
            else
            {
                button16.Text = "OFF";
                button16.BackColor = Color.Gray;
                on16 = true;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (on17)
            {
                button17.Text = "ON";
                button17.BackColor = Color.Red;
                on17 = false;

            }
            else
            {
                button17.Text = "OFF";
                button17.BackColor = Color.Gray;
                on17 = true;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (on18)
            {
                button18.Text = "ON";
                button18.BackColor = Color.Red;
                on18 = false;

            }
            else
            {
                button18.Text = "OFF";
                button18.BackColor = Color.Gray;
                on18 = true;
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (on19)
            {
                button19.Text = "ON";
                button19.BackColor = Color.Red;
                on19 = false;

            }
            else
            {
                button19.Text = "OFF";
                button19.BackColor = Color.Gray;
                on19 = true;
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (on20)
            {
                button20.Text = "ON";
                button20.BackColor = Color.Red;
                on20 = false;

            }
            else
            {
                button20.Text = "OFF";
                button20.BackColor = Color.Gray;
                on20 = true;
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (on21)
            {
                button21.Text = "ON";
                button21.BackColor = Color.Red;
                on21 = false;

            }
            else
            {
                button21.Text = "OFF";
                button21.BackColor = Color.Gray;
                on21 = true;
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (on22)
            {
                button22.Text = "ON";
                button22.BackColor = Color.Red;
                on22 = false;

            }
            else
            {
                button22.Text = "OFF";
                button22.BackColor = Color.Gray;
                on22 = true;
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (on23)
            {
                button23.Text = "ON";
                button23.BackColor = Color.Red;
                on23 = false;

            }
            else
            {
                button23.Text = "OFF";
                button23.BackColor = Color.Gray;
                on23 = true;
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (on24)
            {
                button24.Text = "ON";
                button24.BackColor = Color.Red;
                on24 = false;

            }
            else
            {
                button24.Text = "OFF";
                button24.BackColor = Color.Gray;
                on24 = true;
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (on25)
            {
                button1.Text = "ON";
                button1.BackColor = Color.Red;
                on1 = false;

                button2.Text = "ON";
                button2.BackColor = Color.Red;
                on2 = false;

                button3.Text = "ON";
                button3.BackColor = Color.Red;
                on3 = false;

                button4.Text = "ON";
                button4.BackColor = Color.Red;
                on4 = false;

                button5.Text = "ON";
                button5.BackColor = Color.Red;
                on5 = false;

                button6.Text = "ON";
                button6.BackColor = Color.Red;
                on6 = false;

                button7.Text = "ON";
                button7.BackColor = Color.Red;
                on7 = false;

                button8.Text = "ON";
                button8.BackColor = Color.Red;
                on8 = false;

                button9.Text = "ON";
                button9.BackColor = Color.Red;
                on9 = false;

                button10.Text = "ON";
                button10.BackColor = Color.Red;
                on10 = false;

                button11.Text = "ON";
                button11.BackColor = Color.Red;
                on11 = false;

                button12.Text = "ON";
                button12.BackColor = Color.Red;
                on12 = false;

                button13.Text = "ON";
                button13.BackColor = Color.Red;
                on13 = false;

                button14.Text = "ON";
                button14.BackColor = Color.Red;
                on14 = false;

                button15.Text = "ON";
                button15.BackColor = Color.Red;
                on15 = false;

                button16.Text = "ON";
                button16.BackColor = Color.Red;
                on16 = false;

                button17.Text = "ON";
                button17.BackColor = Color.Red;
                on17 = false;

                button18.Text = "ON";
                button18.BackColor = Color.Red;
                on18 = false;

                button19.Text = "ON";
                button19.BackColor = Color.Red;
                on19 = false;

                button20.Text = "ON";
                button20.BackColor = Color.Red;
                on20 = false;

                button21.Text = "ON";
                button21.BackColor = Color.Red;
                on21 = false;

                button22.Text = "ON";
                button22.BackColor = Color.Red;
                on22 = false;

                button23.Text = "ON";
                button23.BackColor = Color.Red;
                on23 = false;

                button24.Text = "ON";
                button24.BackColor = Color.Red;
                on24 = false;

                button25.Text = "ALL ON";
                button25.BackColor = Color.Red;
                on25 = false;
            }
            else
            {
                button1.Text = "OFF";
                button1.BackColor = Color.Gray;
                on1 = true;

                button2.Text = "OFF";
                button2.BackColor = Color.Gray;
                on2 = true;

                button3.Text = "OFF";
                button3.BackColor = Color.Gray;
                on3 = true;

                button4.Text = "OFF";
                button4.BackColor = Color.Gray;
                on4 = true;

                button5.Text = "OFF";
                button5.BackColor = Color.Gray;
                on5 = true;

                button6.Text = "OFF";
                button6.BackColor = Color.Gray;
                on6 = true;

                button7.Text = "OFF";
                button7.BackColor = Color.Gray;
                on7 = true;

                button8.Text = "OFF";
                button8.BackColor = Color.Gray;
                on8 = true;

                button9.Text = "OFF";
                button9.BackColor = Color.Gray;
                on9 = true;

                button10.Text = "OFF";
                button10.BackColor = Color.Gray;
                on10 = true;

                button11.Text = "OFF";
                button11.BackColor = Color.Gray;
                on11 = true;

                button12.Text = "OFF";
                button12.BackColor = Color.Gray;
                on12 = true;

                button13.Text = "OFF";
                button13.BackColor = Color.Gray;
                on13 = true;

                button14.Text = "OFF";
                button14.BackColor = Color.Gray;
                on14 = true;

                button15.Text = "OFF";
                button15.BackColor = Color.Gray;
                on15 = true;

                button16.Text = "OFF";
                button16.BackColor = Color.Gray;
                on16 = true;

                button17.Text = "OFF";
                button17.BackColor = Color.Gray;
                on17 = true;

                button18.Text = "OFF";
                button18.BackColor = Color.Gray;
                on18 = true;

                button19.Text = "OFF";
                button19.BackColor = Color.Gray;
                on19 = true;

                button20.Text = "OFF";
                button20.BackColor = Color.Gray;
                on20 = true;

                button21.Text = "OFF";
                button21.BackColor = Color.Gray;
                on21 = true;

                button22.Text = "OFF";
                button22.BackColor = Color.Gray;
                on22 = true;

                button23.Text = "OFF";
                button23.BackColor = Color.Gray;
                on23 = true;

                button24.Text = "OFF";
                button24.BackColor = Color.Gray;
                on24 = true;

                button25.Text = "ALL OFF";
                button25.BackColor = Color.Gray;
                on25 = true;
            }
        }

        public void timer2_Tick(object sender, EventArgs e)
        {

            S = S - 1;
            if (S == -1)
            {
                M = M - 1;
                S = 59;
            }

            if (S == 0 && M == 0)
            {
                timer2.Stop();

                port.Write("#ENDS\n");

                label7.Text = "00";
                label8.Text = "00";

                {
                    button1.Text = "OFF";
                    button1.BackColor = Color.Gray;
                    on1 = true;

                    button2.Text = "OFF";
                    button2.BackColor = Color.Gray;
                    on2 = true;

                    button3.Text = "OFF";
                    button3.BackColor = Color.Gray;
                    on3 = true;

                    button4.Text = "OFF";
                    button4.BackColor = Color.Gray;
                    on4 = true;

                    button5.Text = "OFF";
                    button5.BackColor = Color.Gray;
                    on5 = true;

                    button6.Text = "OFF";
                    button6.BackColor = Color.Gray;
                    on6 = true;

                    button7.Text = "OFF";
                    button7.BackColor = Color.Gray;
                    on7 = true;

                    button8.Text = "OFF";
                    button8.BackColor = Color.Gray;
                    on8 = true;

                    button9.Text = "OFF";
                    button9.BackColor = Color.Gray;
                    on9 = true;

                    button10.Text = "OFF";
                    button10.BackColor = Color.Gray;
                    on10 = true;

                    button11.Text = "OFF";
                    button11.BackColor = Color.Gray;
                    on11 = true;

                    button12.Text = "OFF";
                    button12.BackColor = Color.Gray;
                    on12 = true;

                    button13.Text = "OFF";
                    button13.BackColor = Color.Gray;
                    on13 = true;

                    button14.Text = "OFF";
                    button14.BackColor = Color.Gray;
                    on14 = true;

                    button15.Text = "OFF";
                    button15.BackColor = Color.Gray;
                    on15 = true;

                    button16.Text = "OFF";
                    button16.BackColor = Color.Gray;
                    on16 = true;

                    button17.Text = "OFF";
                    button17.BackColor = Color.Gray;
                    on17 = true;

                    button18.Text = "OFF";
                    button18.BackColor = Color.Gray;
                    on18 = true;

                    button19.Text = "OFF";
                    button19.BackColor = Color.Gray;
                    on19 = true;

                    button20.Text = "OFF";
                    button20.BackColor = Color.Gray;
                    on20 = true;

                    button21.Text = "OFF";
                    button21.BackColor = Color.Gray;
                    on21 = true;

                    button22.Text = "OFF";
                    button22.BackColor = Color.Gray;
                    on22 = true;

                    button23.Text = "OFF";
                    button23.BackColor = Color.Gray;
                    on23 = true;

                    button24.Text = "OFF";
                    button24.BackColor = Color.Gray;
                    on24 = true;

                    button25.Text = "ALL OFF";
                    button25.BackColor = Color.Gray;
                    on25 = true;
                }
                string text = "Experiment Complete";
                MessageBox.Show(text);

            }

            string minutes = Convert.ToString(M);
            string seconds = Convert.ToString(S);

            label7.Text = minutes;
            label8.Text = seconds;
        }  



        public void button26_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "0";
            }

            if (textBox2.Text == "")
            {
                textBox2.Text = "0";
            }

            M = Convert.ToInt32(textBox1.Text);
            S = Convert.ToInt32(textBox2.Text);

            if (on1 == false)
            {
                port.Write("#01on\n");
            }
            if (on2 == false)
            {
                port.Write("#02on\n");
            }
            if (on3 == false)
            {
                port.Write("#03on\n");
            }
            if (on4 == false)
            {
                port.Write("#04on\n");
            }
            if (on5 == false)
            {
                port.Write("#05on\n");
            }
            if (on6 == false)
            {
                port.Write("#06on\n");
            }
            if (on7 == false)
            {
                port.Write("#07on\n");
            }
            if (on8 == false)
            {
                port.Write("#08on\n");
            }
            if (on9 == false)
            {
                port.Write("#09on\n");
            }
            if (on10 == false)
            {
                port.Write("#10on\n");
            }
            if (on11 == false)
            {
                port.Write("#11on\n");
            }
            if (on12 == false)
            {
                port.Write("#12on\n");
            }
            if (on13 == false)
            {
                port.Write("#13on\n");
            }
            if (on14 == false)
            {
                port.Write("#14on\n");
            }
            if (on15 == false)
            {
                port.Write("#15on\n");
            }
            if (on16 == false)
            {
                port.Write("#16on\n");
            }
            if (on17 == false)
            {
                port.Write("#17on\n");
            }
            if (on18 == false)
            {
                port.Write("#18on\n");
            }
            if (on19 == false)
            {
                port.Write("#19on\n");
            }
            if (on20 == false)
            {
                port.Write("#20on\n");
            }
            if (on21 == false)
            {
                port.Write("#21on\n");
            }
            if (on22 == false)
            {
                port.Write("#22on\n");
            }
            if (on23 == false)
            {
                port.Write("#23on\n");
            }
            if (on24 == false)
            {
                port.Write("#24on\n");
            }

            timer2.Start();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button27_Click(object sender, EventArgs e)
        {
            if (!Connection)
            {
                connectToArduino();
            }
            else
            {
                disconnectFromArduino();
            }

        }

        
    }


}
